import {  Text  } from 'react-native';

export default function Profile(){

    return(
        <Text>Profile non fonctionnel</Text>
    );
}