export default function Settings(){
    return(
          <Text>Paramètre non fonctionnel</Text>
    );
}